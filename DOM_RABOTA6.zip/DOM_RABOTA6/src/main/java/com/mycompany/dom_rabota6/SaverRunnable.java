package com.mycompany.dom_rabota6;

import com.mycompany.dom_rabota6.Plant;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SaverRunnable implements Runnable {

    private Plant plant;
    private String path;

    public SaverRunnable(Plant plant, String path) {
        this.plant = plant;
        this.path = path;
    }

    @Override
    public void run() {
        if (plant != null && path != null) {
            FileOutputStream fos;
            try {
                fos = new FileOutputStream(path);
                ObjectOutputStream oos = new ObjectOutputStream(fos);
                oos.writeObject(plant);
                oos.close();
                System.out.println("Растение успешно сериализовано");
            } catch (IOException e) {
                System.out.println("Ошибка! Не удалось сохранить растение в файл по пути: " + path);
            }
        }
    }

    public Plant getPlant() {
        return plant;
    }

    public void setPlant(Plant plant) {
        this.plant = plant;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
