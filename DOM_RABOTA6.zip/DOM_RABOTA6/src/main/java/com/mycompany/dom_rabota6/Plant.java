package com.mycompany.dom_rabota6;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

public class Plant implements Externalizable {

    private String specieOfPlant;
    private String breed;
    private double heightInMeters;
    private double ageInYears;
    private String habitat;

    public Plant() {}

    public Plant(String specieOfPlant, String breed, double heightInMeters, double ageInYears, String habitat) {
        this.specieOfPlant = specieOfPlant;
        this.breed = breed;
        this.heightInMeters = heightInMeters;
        this.ageInYears = ageInYears;
        this.habitat = habitat;
    }

    @Override
    public String toString() {
        return "Plant{" +
                "specieOfPlant='" + specieOfPlant + '\'' +
                ", breed='" + breed + '\'' +
                ", heightInMeters=" + heightInMeters +
                ", ageInYears=" + ageInYears +
                ", habitat='" + habitat + '\'' +
                '}';
    }

    public String getSpecieOfPlant() {
        return specieOfPlant;
    }

    public void setSpecieOfPlant(String specieOfPlant) {
        this.specieOfPlant = specieOfPlant;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public double getHeightInMeters() {
        return heightInMeters;
    }

    public void setHeightInMeters(double heightInMeters) {
        this.heightInMeters = heightInMeters;
    }

    public double getAgeInYears() {
        return ageInYears;
    }

    public void setAgeInYears(double ageInYears) {
        this.ageInYears = ageInYears;
    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(getSpecieOfPlant());
        out.writeObject(getBreed());
        out.writeObject(getHeightInMeters());
        out.writeObject(getAgeInYears());
        out.writeObject(getHabitat());
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        specieOfPlant = (String) in.readObject();
        breed = (String) in.readObject();
        heightInMeters = (Double) in.readObject();
        ageInYears = (Double) in.readObject();
        habitat = (String) in.readObject();
    }
}
