/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dom_rabota6;

/**
 *
 * @author User
 */
import java.util.Scanner;

public class DOM_RABOTA6 {
    public static void main(String[] args) {
        System.out.println("Трохин Александр Андреевич");
        System.out.println("РИБО-01-21");

        String specie, breed, habitat;
        double age, height;

        while (true) {
            System.out.println();
            System.out.println("Введите тип растения (дерево, куст, цевток и т.д.):");
            specie = scan();
            if (specie.isEmpty() || specie.isBlank()) {
                System.out.println("Поле \"Тип ратсения\" должно быть заполнено");
                continue;
            }
            break;
        }

        while (true) {
            System.out.println();
            System.out.println("Введите вид растения (порода):");
            breed = scan();
            if (breed.isEmpty() || breed.isBlank()) {
                System.out.println("Поле \"Вид растения\" должно быть заполнено");
                continue;
            }
            break;
        }

        while (true) {
            System.out.println();
            System.out.println("Введите рост растения (в метрах):");
            try {
                height = Double.parseDouble(scan());
                if (height <= 0) {
                    System.out.println("Рост растения должен быть больше нуля");
                    continue;
                }
                break;
            } catch (NumberFormatException e) {
                System.out.println("Необходимо ввести число больше 0");
            }
        }

        while (true) {
            System.out.println();
            System.out.println("Введите возраст растения (в годах):");
            try {
                age = Double.parseDouble(scan());
                if (age <= 0) {
                    System.out.println("Возраст растения должен быть больше нуля");
                    continue;
                }
                break;
            } catch (NumberFormatException e) {
                System.out.println("Необходимо ввести число больше 0");
            }
        }

        while (true) {
            System.out.println();
            System.out.println("Введите место обитания растения:");
            habitat = scan();
            if (habitat.isEmpty() || habitat.isBlank()) {
                System.out.println("Поле \"Место обитания\" должно быть заполнено");
                continue;
            }
            break;
        }

        Plant plant = new Plant(specie, breed, height, age, habitat);

        System.out.println("Растение создано!");
        System.out.println(plant);

        String fileName;
        while (true) {
            System.out.println();
            System.out.println("Придумайте имя файлу, куда сохранить машину (без расширения):");
            fileName = scan();
            if (fileName.isEmpty() || fileName.isBlank()) {
                System.out.println("Нужно ввести имя файла");
                continue;
            }
            break;
        }

        String fileExtension;
        while (true) {
            System.out.println();
            System.out.println("Введите расширение файла (без точки):");
            System.out.println("Пример: txt  docx  ser и т.д. (любое расширение)");
            fileExtension = scan();
            if (fileExtension.isEmpty() || fileExtension.isBlank()) {
                System.out.println("Нужно ввести расширение файла");
                continue;
            }
            break;
        }

        SaverRunnable saver = new SaverRunnable(plant, "C:\\" + fileName + "." + fileExtension);

        Thread thread = new Thread(saver);
        thread.start();
    }

    public static String scan() {
        return new Scanner(System.in).nextLine();
    }
}

 
